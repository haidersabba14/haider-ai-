/** Haider ai Worker: verified Supabase email-session -> real OpenAI -> Postgres.
 * No mock replies. Missing configuration produces an error, never a fake success.
 */
interface Env {
  SUPABASE_URL: string;
  SUPABASE_ANON_KEY: string;
  SUPABASE_SERVICE_ROLE_KEY: string;
  OPENAI_API_KEY: string;
  OPENAI_MODEL?: string;
  RATE_LIMITER?: { limit(input: { key: string }): Promise<{ success: boolean }> };
}
type User = { id: string; email?: string };
type Message = { role: 'user' | 'assistant'; content: string };
const JSON_HEADERS = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };
function response(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
}
function adminHeaders(env: Env) {
  return {
    apikey: env.SUPABASE_SERVICE_ROLE_KEY,
    authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`,
    'content-type': 'application/json',
  };
}
function base(env: Env) { return env.SUPABASE_URL.replace(/\/$/, ''); }
async function authenticate(token: string, env: Env): Promise<User | null> {
  const result = await fetch(`${base(env)}/auth/v1/user`, {
    headers: { apikey: env.SUPABASE_ANON_KEY, authorization: `Bearer ${token}` },
  });
  if (!result.ok) return null;
  const user = await result.json() as User;
  return /^[0-9a-f-]{36}$/i.test(user.id ?? '') ? user : null;
}
async function queryRows<T>(env: Env, table: string, filters: string, limit?: number): Promise<T[]> {
  const url = `${base(env)}/rest/v1/${table}?${filters}${limit ? `&limit=${limit}` : ''}`;
  const r = await fetch(url, { headers: adminHeaders(env) });
  if (!r.ok) throw new Error(`${table} read failed: ${r.status}`);
  return await r.json() as T[];
}
async function insertRow<T>(env: Env, table: string, row: Record<string, unknown>): Promise<T> {
  const r = await fetch(`${base(env)}/rest/v1/${table}`, {
    method: 'POST', headers: { ...adminHeaders(env), prefer: 'return=representation' }, body: JSON.stringify(row),
  });
  if (!r.ok) throw new Error(`${table} insert failed: ${r.status}`);
  const rows = await r.json() as T[];
  if (!rows.length) throw new Error(`${table} did not return row`);
  return rows[0];
}
function extractOutput(body: any): string {
  if (typeof body.output_text === 'string' && body.output_text.trim()) return body.output_text.trim();
  return (body.output ?? []).flatMap((o: any) => o.content ?? [])
    .filter((c: any) => c.type === 'output_text' && typeof c.text === 'string')
    .map((c: any) => c.text).join('\n').trim();
}
async function chat(request: Request, env: Env): Promise<Response> {
  const bearer = /^Bearer (.+)$/i.exec(request.headers.get('authorization') ?? '')?.[1];
  if (!bearer) return response({ error: 'يلزم تسجيل الدخول' }, 401);
  const user = await authenticate(bearer, env);
  if (!user) return response({ error: 'انتهت الجلسة أو أنها غير صالحة' }, 401);
  if (env.RATE_LIMITER) {
    const verdict = await env.RATE_LIMITER.limit({ key: user.id });
    if (!verdict.success) return response({ error: 'طلبات كثيرة، حاول لاحقًا' }, 429);
  }

  const body = await request.json().catch(() => null) as { message?: unknown; conversationId?: unknown } | null;
  const message = typeof body?.message === 'string' ? body.message.trim() : '';
  if (!message || message.length > 4000) return response({ error: 'اكتب رسالة من 1 إلى 4000 حرف' }, 400);
  const conversationId = body?.conversationId;
  if (conversationId != null && (typeof conversationId !== 'string' || !/^[a-f0-9-]{36}$/i.test(conversationId))) {
    return response({ error: 'معرّف المحادثة غير صالح' }, 400);
  }

  // Daily cost cap, in addition to optional Cloudflare rate limiting.
  // A stricter atomic quota/concurrency limiter should be configured before public launch.
  const today = new Date(); today.setUTCHours(0, 0, 0, 0);
  const usage = await queryRows<{id: string}>(env, 'usage_records',
    `select=id&user_id=eq.${encodeURIComponent(user.id)}&created_at=gte.${encodeURIComponent(today.toISOString())}`, 21);
  if (usage.length >= 20) return response({ error: 'وصلت الحد اليومي (20 طلبًا)' }, 429);

  let id = conversationId as string | undefined;
  if (id) {
    const rows = await queryRows<{id:string}>(env, 'conversations',
      `select=id&id=eq.${encodeURIComponent(id)}&user_id=eq.${encodeURIComponent(user.id)}`, 1);
    if (rows.length === 0) return response({ error: 'المحادثة غير موجودة أو غير مصرح بها' }, 404);
  } else {
    const created = await insertRow<{id:string}>(env, 'conversations', {
      user_id: user.id, title: message.slice(0, 50),
    });
    id = created.id;
  }

  // Read only messages belonging to a conversation verified above.
  const previous = await queryRows<Message & {created_at: string}>(env, 'messages',
    `select=role,content,created_at&conversation_id=eq.${encodeURIComponent(id)}&order=created_at.desc`, 12);
  const history = previous.reverse().map(({role, content}) => ({ role, content }));
  const model = env.OPENAI_MODEL || 'gpt-4.1-mini';
  const aiResponse = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: { authorization: `Bearer ${env.OPENAI_API_KEY}`, 'content-type': 'application/json' },
    body: JSON.stringify({
      model, max_output_tokens: 750,
      instructions: 'You are Haider ai, a helpful, accurate AI assistant. Reply in the user\'s language. Never claim to have performed unverified external actions.',
      input: [...history, { role: 'user', content: message }],
    }),
  });
  if (!aiResponse.ok) {
    // Deliberately do NOT return provider details or secrets to the mobile app.
    console.error('AI provider error', aiResponse.status);
    return response({ error: 'تعذر الاتصال بمزود الذكاء الاصطناعي' }, 502);
  }
  const aiBody = await aiResponse.json() as any;
  const answer = extractOutput(aiBody);
  if (!answer) return response({ error: 'لم يرجع المزود نصًا صالحًا' }, 502);

  // Persist only after a real provider response, never a simulated response.
  await insertRow(env, 'messages', { conversation_id: id, role: 'user', content: message });
  await insertRow(env, 'messages', { conversation_id: id, role: 'assistant', content: answer });
  await insertRow(env, 'usage_records', {
    user_id: user.id, provider: 'openai', model, request_id: aiBody.id ?? null,
    input_tokens: aiBody.usage?.input_tokens ?? null,
    output_tokens: aiBody.usage?.output_tokens ?? null,
  });
  return response({ conversationId: id, reply: answer });
}
export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const path = new URL(request.url).pathname;
    if (path === '/health' && request.method === 'GET') {
      return response({ service: 'Haider ai', status: 'process-running', note: 'Not an AI/auth connectivity test' });
    }
    if (path !== '/chat' || request.method !== 'POST') return response({ error: 'Not found' }, 404);
    // Reject untrusted browser Origins; React Native requests normally have no Origin header.
    if (request.headers.get('origin')) return response({ error: 'Browser origin not allowed' }, 403);
    if (!env.SUPABASE_URL || !env.SUPABASE_ANON_KEY || !env.SUPABASE_SERVICE_ROLE_KEY || !env.OPENAI_API_KEY) {
      return response({ error: 'الخادم غير مهيأ' }, 503);
    }
    try {
      return await chat(request, env);
    } catch (e) {
      console.error('Haider ai backend request failed', e instanceof Error ? e.message : 'unknown');
      return response({ error: 'خطأ في الخادم' }, 500);
    }
  },
};
