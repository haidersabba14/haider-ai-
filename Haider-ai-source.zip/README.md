# Haider ai — native iOS / Android + real cloud backend (MVP source)

**Status: Source code only. Not yet deployed, compiled, signed, or integration-tested.** No real accounts have been created and no emails/AI calls have been made by this delivery. This is a connected-ready MVP starter, **not** a claim that the complete production specification is delivered.

## What is implemented in the source

- React Native / Expo app for both iOS and Android, titled **Haider ai**.
- Actual email OTP flow using `supabase.auth.signInWithOtp()` and `verifyOtp(type:'email')` — no simulated codes.
- Secure mobile session storage through Expo SecureStore.
- Display of previous conversations/messages guarded by Supabase RLS.
- Cloudflare Worker checks bearer token against Supabase Auth, verifies conversation ownership, calls the **real** OpenAI Responses API from the server, then saves user + assistant messages and usage records.
- SQL schemas for ten user-data tables, RLS, and a real two-user authorization test (`tests/rls.mjs`).
- Dark purple Arabic UI and branded OTP email template.
- Optional Cloudflare rate-limit binding + a non-atomic daily quota guard. **Add atomic metering before public production launch.**

## 1. Prepare Supabase (real project)

1. Create or choose **your own** Supabase project (the project must be authorized).
2. Open SQL Editor, execute `supabase/schema.sql` and check for **Success**.
3. In **Authentication → Providers → Email**, enable email sign-ins. Confirm email/OTP settings and avoid auto-confirm unless intentionally desired.
4. In **Authentication → Email Templates**, edit the **Magic Link** template to contain `{{ .Token }}` (not `{{ .ConfirmationURL }}`) using `emails/otp-ar.html`. This changes the `signInWithOtp` email to an OTP instead of a clickable link. Set subject: `Haider ai | رمز التحقق من حسابك`.
5. In **Project Settings → API Keys**, copy the project URL and public publishable/anon key into `mobile/.env`; **never** put the service role key in the app.
6. Verify every table's RLS status in the Supabase dashboard.

Source: https://supabase.com/docs/reference/javascript/auth-signinwithotp

## 2. Set up REAL email SMTP with Resend

1. Register and verify a domain **you own** in Resend. Configure the precise SPF/DKIM (and preferably DMARC) DNS records Resend supplies. No domain is included in this project.
2. In **Supabase → Auth → SMTP**, turn on Custom SMTP and enter:
   - Host: `smtp.resend.com`
   - Port: `465` (SSL/TLS; if the service requires STARTTLS use the configured supported port)
   - Username: `resend`
   - Password: your private Resend API key, entered only in the Supabase SMTP settings
   - Sender: `Haider ai <noreply@YOUR-VERIFIED-DOMAIN>`
3. Check Supabase Auth rate limits and OTP expiration settings. Apply practical cooldown between sends, server-side rate limits, and monitoring for abuse.
4. From a **real inbox that you control**, request an OTP and confirm arrival. Check Resend delivery logs (accepted/delivered/bounced), spam, and verify the OTP opens a valid user session.
5. Without custom SMTP, Supabase's default email service is **limited and unsuitable for production**, including restricted recipients. Do not interpret the OTP request API succeeding as guaranteed delivery.

Reference: https://supabase.com/docs/guides/auth/auth-smtp

## 3. Deploy Cloudflare Worker

```bash
cd backend
npm install
npx wrangler login
npx wrangler secret put SUPABASE_URL
npx wrangler secret put SUPABASE_ANON_KEY
npx wrangler secret put SUPABASE_SERVICE_ROLE_KEY
npx wrangler secret put OPENAI_API_KEY
npm run deploy
```

The Worker returns the actual deployment URL on success; **do not invent a URL**. The service role key and OpenAI key must exist only in Cloudflare secrets. The `OPENAI_MODEL` variable is optional (`gpt-4.1-mini` by default). A model/provider API account with credits/billing may be required.

`GET /health` proves only that the Worker process runs. **It does not prove** Auth, SMTP, database or OpenAI connectivity. Run a real signed-in `/chat` request and verify a saved `assistant` response in the database.

This configuration enables a native Cloudflare Rate Limiting binding: **5 requests per 60 seconds, per user, per location (approximate)**. The SQL usage cap is not atomic under concurrent traffic; use Durable Objects or an atomic database quota before exposing public billing. Track costs.

Reference: https://developers.cloudflare.com/workers/runtime-apis/bindings/rate-limit/

## 4. Configure and run the mobile app

```bash
cd mobile
cp .env.example .env
# Edit .env and set your ACTUAL values (not example URLs):
# EXPO_PUBLIC_SUPABASE_URL=...
# EXPO_PUBLIC_SUPABASE_ANON_KEY=...    (public key only)
# EXPO_PUBLIC_API_BASE_URL=...       (Worker URL, no trailing slash)
npm install
npx expo start
```

The client must never receive `OPENAI_API_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, or Resend SMTP credentials. The app explicitly shows a configuration warning if URLs/keys are not set. Do not paste secrets into chat.

## 5. Verify cross-account isolation — actual test

Get two JWT access tokens by signing into **two distinct real Supabase accounts**, then run:

```bash
SUPABASE_URL='YOUR_REAL_SUPABASE_URL' SUPABASE_ANON_KEY='YOUR_PUBLIC_KEY' \
USER_A_JWT='TOKEN_A' USER_B_JWT='TOKEN_B' node tests/rls.mjs
```

Expected: A can create a conversation; B cannot read A's conversation or messages, and cannot insert a message into A's conversation. The test deletes its test conversation. **It has not been run in this package**, since no authorized project/credentials were supplied.

## 6. Build APK / IPA

```bash
npm install -g eas-cli
cd mobile
eas login
eas build:configure
# Android installable APK (building itself can be free within plan limits):
eas build -p android --profile preview
# iOS simulator artifact, not installable on physical iPhone:
eas build -p ios --profile simulator
# iOS physical device (requires proper Apple signing credentials):
eas build -p ios --profile preview
```

Important: Apple iOS physical device builds via EAS normally require an **Apple Developer Program** membership. If you have a Mac, **Xcode can support some personal-development signing options** without the paid program, with limitations. TrollStore cannot compile an IPA: it only installs compatible packages on compatible devices. No IPA or APK is claimed to have been built here.

Reference: https://docs.expo.dev/tutorial/eas/ios-development-build-for-devices/

## Scope limitations of this starter

This project currently implements the **first priority**: email OTP sign-in, real text chat through **OpenAI**, and persistent conversations. It does **not** yet implement Anthropic, Gemini, DeepSeek, real streaming, image/video creation, Google/Apple OAuth, password reset/change, full account deletion workflow, file uploads, Cloudflare R2, queues, Cron, push notifications, offline queue, all project/task screens, or full production observability. SQL tables alone do not mean their features are implemented.

Before any public launch, add security review, atomic paid-usage quotas, rate limiting on OTP requests, monitoring, robust mobile session refresh testing, retries/idempotency on message persistence, full GDPR/privacy/account-deletion handling, AI moderation/cost controls, and end-to-end real-device checks.

**Costs:** the source package is free. Domain registration, OpenAI API usage, some email/backend usage and iOS signing/distribution may cost money, depending on services and volumes.
