-- HAIDER AI / Supabase schema. Apply in a NEW, authorized project.
-- All user-data tables use RLS. Run with SQL Editor/project admin credentials.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Haider ai user',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'محادثة جديدة',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists conversations_owner_time on public.conversations(user_id, updated_at desc);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null check (char_length(content) between 1 and 20000),
  created_at timestamptz not null default now()
);
create index if not exists messages_conv_time on public.messages(conversation_id, created_at desc);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  name text not null, description text, created_at timestamptz not null default now()
);
create index if not exists projects_owner_idx on public.projects(user_id);

create table if not exists public.ai_tasks (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null, status text not null default 'queued' check (status in ('queued','running','done','failed')),
  result jsonb, created_at timestamptz not null default now()
);
create index if not exists ai_tasks_owner_idx on public.ai_tasks(user_id, created_at desc);

create table if not exists public.generated_files (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  object_key text not null, mime_type text, created_at timestamptz not null default now()
);
create index if not exists generated_files_owner_idx on public.generated_files(user_id);

create table if not exists public.user_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  settings jsonb not null default '{}'::jsonb, updated_at timestamptz not null default now()
);
create table if not exists public.memory_entries (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  content text not null, created_at timestamptz not null default now()
);
create index if not exists memory_owner_idx on public.memory_entries(user_id);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  content text not null, is_read boolean not null default false, created_at timestamptz not null default now()
);
create index if not exists notifications_owner_idx on public.notifications(user_id, created_at desc);
create table if not exists public.usage_records (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null, model text not null, request_id text, input_tokens integer, output_tokens integer,
  created_at timestamptz not null default now()
);
create index if not exists usage_owner_time on public.usage_records(user_id, created_at desc);

-- A profile is created on the actual signup; never manually store passwords.
create or replace function public.handle_new_haider_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles(id) values (new.id) on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_haider_user_created on auth.users;
create trigger on_haider_user_created after insert on auth.users
for each row execute procedure public.handle_new_haider_user();

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.projects enable row level security;
alter table public.ai_tasks enable row level security;
alter table public.generated_files enable row level security;
alter table public.user_preferences enable row level security;
alter table public.memory_entries enable row level security;
alter table public.notifications enable row level security;
alter table public.usage_records enable row level security;

-- Profile: a user may read/edit their own profile, not mint a new profile for someone else.
drop policy if exists profile_own_select on public.profiles;
create policy profile_own_select on public.profiles for select to authenticated using ((select auth.uid()) = id);
drop policy if exists profile_own_update on public.profiles;
create policy profile_own_update on public.profiles for update to authenticated using ((select auth.uid()) = id) with check ((select auth.uid()) = id);

-- Conversations are owned directly by their user.
drop policy if exists conversation_read on public.conversations;
create policy conversation_read on public.conversations for select to authenticated using ((select auth.uid()) = user_id);
drop policy if exists conversation_insert on public.conversations;
create policy conversation_insert on public.conversations for insert to authenticated with check ((select auth.uid()) = user_id);
drop policy if exists conversation_edit on public.conversations;
create policy conversation_edit on public.conversations for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
drop policy if exists conversation_delete on public.conversations;
create policy conversation_delete on public.conversations for delete to authenticated using ((select auth.uid()) = user_id);

-- Message access is checked against the parent conversation.
drop policy if exists message_read on public.messages;
create policy message_read on public.messages for select to authenticated using (
 exists(select 1 from public.conversations c where c.id = conversation_id and c.user_id = (select auth.uid()))
);
-- Clients cannot create assistant responses; only the authenticated server may do this.
drop policy if exists message_user_insert on public.messages;
create policy message_user_insert on public.messages for insert to authenticated with check (
 role = 'user' and exists(select 1 from public.conversations c where c.id = conversation_id and c.user_id = (select auth.uid()))
);

-- Remaining objects are private. The server uses service credentials ONLY on server-side.
do $$ declare t text; begin
 foreach t in array array['projects','ai_tasks','generated_files','memory_entries','notifications','usage_records'] loop
  execute format('drop policy if exists %I on public.%I', t || '_read', t);
  execute format('create policy %I on public.%I for select to authenticated using ((select auth.uid()) = user_id)', t || '_read', t);
 end loop;
end $$;
-- Projects may be managed by the owning user.
drop policy if exists project_insert on public.projects;
create policy project_insert on public.projects for insert to authenticated with check ((select auth.uid())=user_id);
drop policy if exists project_update on public.projects;
create policy project_update on public.projects for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
drop policy if exists project_delete on public.projects;
create policy project_delete on public.projects for delete to authenticated using ((select auth.uid())=user_id);
-- Memory is opt-in; clients may manage only their own entries.
drop policy if exists memory_insert on public.memory_entries;
create policy memory_insert on public.memory_entries for insert to authenticated with check ((select auth.uid())=user_id);
drop policy if exists memory_delete on public.memory_entries;
create policy memory_delete on public.memory_entries for delete to authenticated using ((select auth.uid())=user_id);
-- Preferences / notifications are private.
drop policy if exists preferences_select on public.user_preferences;
create policy preferences_select on public.user_preferences for select to authenticated using ((select auth.uid())=user_id);
drop policy if exists preferences_insert on public.user_preferences;
create policy preferences_insert on public.user_preferences for insert to authenticated with check ((select auth.uid())=user_id);
drop policy if exists preferences_update on public.user_preferences;
create policy preferences_update on public.user_preferences for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
drop policy if exists notification_update on public.notifications;
create policy notification_update on public.notifications for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
