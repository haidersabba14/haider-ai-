// Integration test against two REAL, independently authenticated Supabase users.
// No fake sessions. Supply A/B access tokens obtained by signing in normally.
const { SUPABASE_URL, SUPABASE_ANON_KEY, USER_A_JWT, USER_B_JWT } = process.env;
for (const key of ['SUPABASE_URL', 'SUPABASE_ANON_KEY', 'USER_A_JWT', 'USER_B_JWT']) {
  if (!process.env[key]) throw new Error(`Missing ${key}. No test was run.`);
}
const base = SUPABASE_URL.replace(/\/$/, '');
async function api(token, table, suffix, init = {}) {
  const res = await fetch(`${base}/rest/v1/${table}${suffix}`, {
    ...init, headers: { apikey: SUPABASE_ANON_KEY, authorization: `Bearer ${token}`,
      'content-type': 'application/json', ...(init.headers ?? {}) },
  });
  return {status: res.status, data: await res.json().catch(() => [])};
}
const me = await fetch(`${base}/auth/v1/user`, {headers: {apikey: SUPABASE_ANON_KEY, authorization: `Bearer ${USER_A_JWT}`}});
if (!me.ok) throw new Error('User A JWT is not valid');
const user = await me.json();
const other = await fetch(`${base}/auth/v1/user`, {headers: {apikey: SUPABASE_ANON_KEY, authorization: `Bearer ${USER_B_JWT}`}});
if (!other.ok) throw new Error('User B JWT is not valid');
const bUser = await other.json();
if (user.id === bUser.id) throw new Error('Test requires two DIFFERENT accounts');
const created = await api(USER_A_JWT, 'conversations', '', {
  method: 'POST', headers: {prefer: 'return=representation'},
  body: JSON.stringify({user_id: user.id, title: 'Cross-user isolation test'}),
});
if (created.status !== 201 || !created.data[0]?.id) throw new Error('A cannot create a conversation; check RLS');
const id = created.data[0].id;
try {
  const read = await api(USER_B_JWT, 'conversations', `?select=id&id=eq.${id}`);
  if (read.status !== 200 || read.data.length !== 0) throw new Error('FAIL: B can read A conversation');
  const readMessages = await api(USER_B_JWT, 'messages', `?select=id&conversation_id=eq.${id}`);
  if (readMessages.status !== 200 || readMessages.data.length !== 0) throw new Error('FAIL: B can read A messages');
  const insert = await api(USER_B_JWT, 'messages', '', {
    method: 'POST', body: JSON.stringify({conversation_id: id, role: 'user', content: 'malicious access'}),
  });
  if (insert.status < 400) throw new Error('FAIL: B inserted a message into A conversation');
  console.log('PASS: A created private record, B cannot read or write it.');
} finally {
  const deleted = await api(USER_A_JWT, 'conversations', `?id=eq.${id}`, {method: 'DELETE'});
  if (deleted.status >= 400) console.error('Cleanup: remove the test conversation manually.');
}
