import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';
import * as SecureStore from 'expo-secure-store';
import { AppState, Platform } from 'react-native';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL ?? '';
const key = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '';
export const apiBaseUrl = (process.env.EXPO_PUBLIC_API_BASE_URL ?? '').replace(/\/$/, '');
export const isConfigured = !!(url && key && apiBaseUrl);
const Storage = {
  getItem: async (key: string): Promise<string | null> => SecureStore.getItemAsync(key),
  setItem: async (key: string, value: string): Promise<void> => SecureStore.setItemAsync(key, value),
  removeItem: async (key: string): Promise<void> => SecureStore.deleteItemAsync(key),
};
export const supabase = createClient(url || 'https://missing-config.invalid', key || 'not-configured', {
  auth: { storage: Storage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false },
});
// Only refresh while the app is active (Supabase React Native guidance).
if (Platform.OS !== 'web') {
  AppState.addEventListener('change', (state) => {
    if (state === 'active') supabase.auth.startAutoRefresh();
    else supabase.auth.stopAutoRefresh();
  });
}
