import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, KeyboardAvoidingView, Platform, Pressable, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput, View } from 'react-native';
import type { Session } from '@supabase/supabase-js';
import { apiBaseUrl, isConfigured, supabase } from './supabase';

type Conversation = { id: string; title: string; updated_at: string };
type Message = { id: string; role: 'user' | 'assistant'; content: string; created_at: string };
type AuthScreen = 'email' | 'otp';
const colors = { bg: '#090813', panel: '#161327', panel2: '#211a38', violet: '#9f78ff', muted: '#afa5c4', white: '#f9f7ff', border: '#393050' };

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState(false);
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [authScreen, setAuthScreen] = useState<AuthScreen>('email');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const listRef = useRef<FlatList<Message> | null>(null);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (mounted) { setSession(data.session); setLoading(false); }
    }).catch(() => { if (mounted) setLoading(false); });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, next) => {
      if (mounted) {
        setSession(next);
        if (!next) { setConversationId(null); setMessages([]); setConversations([]); }
      }
    });
    return () => { mounted = false; subscription.unsubscribe(); };
  }, []);
  useEffect(() => { if (session) void loadConversations(); }, [session?.user.id]);

  async function loadConversations() {
    const { data, error: e } = await supabase.from('conversations')
      .select('id,title,updated_at').order('updated_at', { ascending: false }).limit(100);
    if (e) setError('تعذر تحميل المحادثات: ' + e.message);
    else setConversations(data ?? []);
  }
  async function openConversation(id: string) {
    setError(''); setConversationId(id); setMessages([]);
    const { data, error: e } = await supabase.from('messages')
      .select('id,role,content,created_at').eq('conversation_id', id)
      .order('created_at', { ascending: true }).limit(100);
    if (e) setError('تعذر تحميل الرسائل: ' + e.message);
    else setMessages((data ?? []) as Message[]);
  }
  function newConversation() { setConversationId(null); setMessages([]); setError(''); setDraft(''); }

  async function sendOtp() {
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) return setError('أدخل بريدًا إلكترونيًا صحيحًا');
    setError(''); setNotice(''); setWorking(true);
    const { error: e } = await supabase.auth.signInWithOtp({
      email: email.trim().toLowerCase(), options: { shouldCreateUser: true },
    });
    setWorking(false);
    if (e) setError(e.message);
    else { setAuthScreen('otp'); setNotice('أرسلنا طلب الرمز. تحقق من بريدك، وقد يتأخر وصوله.'); }
  }
  async function verifyOtp() {
    if (!/^\d{6,8}$/.test(otp.trim())) return setError('أدخل رمز التحقق الرقمي');
    setError(''); setWorking(true);
    const { error: e } = await supabase.auth.verifyOtp({
      email: email.trim().toLowerCase(), token: otp.trim(), type: 'email',
    });
    setWorking(false);
    if (e) setError('رمز غير صالح أو منتهي الصلاحية: ' + e.message);
    else { setOtp(''); setNotice(''); }
  }

  async function sendMessage() {
    const text = draft.trim();
    if (!text || sending) return;
    if (text.length > 4000) return setError('الرسالة طويلة جدًا');
    setSending(true); setError(''); setDraft('');
    const optimistic: Message = { id: `local-${Date.now()}`, role: 'user', content: text, created_at: new Date().toISOString() };
    setMessages((prev) => [...prev, optimistic]);
    try {
      const { data: { session: activeSession }, error: sessionErr } = await supabase.auth.getSession();
      if (sessionErr || !activeSession?.access_token) throw new Error('انتهت الجلسة؛ سجل الدخول مجددًا');
      const response = await fetch(`${apiBaseUrl}/chat`, {
        method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${activeSession.access_token}` },
        body: JSON.stringify({ message: text, conversationId: conversationId ?? undefined }),
      });
      const body = await response.json().catch(() => ({})) as { reply?: string; conversationId?: string; error?: string };
      if (!response.ok || !body.reply || !body.conversationId) throw new Error(body.error ?? 'لم يصل رد صالح من الخادم');
      setConversationId(body.conversationId);
      setMessages((prev) => [...prev, { id: `reply-${Date.now()}`, role: 'assistant', content: body.reply!, created_at: new Date().toISOString() }]);
      void loadConversations();
    } catch (e) {
      setMessages((prev) => prev.filter((m) => m.id !== optimistic.id));
      setDraft(text);
      setError(e instanceof Error ? e.message : 'تعذر إرسال الرسالة');
    } finally { setSending(false); }
  }

  const bubble = ({ item }: { item: Message }) => (
    <View style={[styles.bubble, item.role === 'user' ? styles.userBubble : styles.aiBubble]}>
      <Text style={styles.bubbleTitle}>{item.role === 'user' ? 'أنت' : '✦ Haider ai'}</Text>
      <Text style={styles.bubbleText}>{item.content}</Text>
    </View>
  );

  if (!isConfigured) return (
    <SafeAreaView style={styles.container}><View style={styles.centered}>
      <Text style={styles.logo}>✦ Haider ai</Text>
      <Text style={styles.title}>التطبيق يحتاج إعدادًا</Text>
      <Text style={styles.muted}>ضع مفاتيح Supabase العامة وعنوان Worker المنشور في mobile/.env قبل التشغيل. لا توجد حسابات أو محادثات تجريبية.</Text>
    </View></SafeAreaView>
  );
  if (loading) return <SafeAreaView style={[styles.container, styles.centered]}><ActivityIndicator size="large" color={colors.violet}/></SafeAreaView>;
  if (!session) return (
    <SafeAreaView style={styles.container}><StatusBar barStyle="light-content"/>
      <ScrollView contentContainerStyle={styles.authContent} keyboardShouldPersistTaps="handled">
        <Text style={styles.logo}>✦ Haider ai</Text>
        <Text style={styles.hero}>ذكاء واحد.{"\n"}إمكانيات بلا حدود.</Text>
        <Text style={styles.muted}>سجل دخولك بالبريد الإلكتروني باستخدام رمز تحقق حقيقي من Supabase Auth.</Text>
        <View style={styles.panel}>
          <Text style={styles.fieldLabel}>{authScreen === 'email' ? 'البريد الإلكتروني' : 'رمز التحقق'}</Text>
          {authScreen === 'email' ? (
            <TextInput style={styles.input} placeholder="you@example.com" placeholderTextColor="#827795"
              autoCapitalize="none" autoCorrect={false} keyboardType="email-address" textContentType="emailAddress"
              value={email} onChangeText={setEmail}/>
          ) : (
            <TextInput style={styles.input} placeholder="123456" placeholderTextColor="#827795" keyboardType="number-pad"
              textContentType="oneTimeCode" value={otp} onChangeText={setOtp} maxLength={8}/>
          )}
          {!!error && <Text style={styles.error}>{error}</Text>}
          {!!notice && <Text style={styles.muted}>{notice}</Text>}
          <Pressable disabled={working} style={styles.primary} onPress={() => void (authScreen === 'email' ? sendOtp() : verifyOtp())}>
            <Text style={styles.primaryText}>{working ? 'جارٍ المعالجة...' : authScreen === 'email' ? 'إرسال رمز التحقق' : 'تأكيد وتسجيل الدخول'}</Text>
          </Pressable>
          {authScreen === 'otp' && <Pressable onPress={() => { setAuthScreen('email'); setOtp(''); setError(''); }}>
            <Text style={styles.link}>تعديل البريد أو إعادة إرسال الرمز</Text>
          </Pressable>}
        </View>
        <Text style={[styles.muted, {textAlign: 'center'}]}>HAIDER AI • SECURE SIGN-IN</Text>
      </ScrollView>
    </SafeAreaView>
  );
  return (
    <SafeAreaView style={styles.container}><StatusBar barStyle="light-content"/>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={10}>
        <View style={styles.header}>
          <View><Text style={styles.logoSmall}>✦ Haider ai</Text><Text style={styles.headerSubtitle}>HAIDER CORE • SECURE</Text></View>
          <Pressable onPress={() => void supabase.auth.signOut()}><Text style={styles.signOut}>خروج</Text></Pressable>
        </View>
        <View style={styles.nav}>
          <Pressable style={styles.newButton} onPress={newConversation}><Text style={styles.newButtonText}>＋ محادثة جديدة</Text></Pressable>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{gap: 8}}>
            {conversations.map(c => (
              <Pressable key={c.id} style={[styles.navPill, c.id === conversationId && styles.navPillActive]} onPress={() => void openConversation(c.id)}>
                <Text numberOfLines={1} style={styles.navPillText}>{c.title}</Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>
        {messages.length === 0 ? (
          <View style={styles.empty}><Text style={styles.sparkle}>✦</Text>
            <Text style={styles.title}>كيف أقدر أساعدك؟</Text>
            <Text style={styles.muted}>محادثتك مع Haider ai تُحفظ في حسابك الحقيقي بعد وصول الرد من خادم الذكاء الاصطناعي.</Text>
          </View>
        ) : <FlatList ref={listRef} style={styles.flex} contentContainerStyle={styles.messages} data={messages}
          keyExtractor={m => m.id} renderItem={bubble} onContentSizeChange={() => listRef.current?.scrollToEnd({animated: true})}/>}
        {!!error && <Text style={styles.chatError}>{error}</Text>}
        {sending && <Text style={styles.thinking}>✦ Haider ai يفكّر...</Text>}
        <View style={styles.composer}>
          <TextInput multiline style={styles.composerInput} placeholder="اسأل Haider ai..." placeholderTextColor="#887c9e"
            value={draft} onChangeText={setDraft} maxLength={4000}/>
          <Pressable disabled={sending || !draft.trim()} style={[styles.sendButton, (sending || !draft.trim()) && {opacity: .55}]} onPress={() => void sendMessage()}>
            <Text style={styles.primaryText}>إرسال ↑</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  flex: {flex: 1}, container: {flex: 1, backgroundColor: colors.bg, paddingTop: Platform.OS === 'android' ? 20 : 0},
  centered: {flex: 1, justifyContent: 'center', alignItems: 'center', padding: 28},
  authContent: {flexGrow: 1, justifyContent: 'center', padding: 25, gap: 20},
  logo: {color: colors.violet, fontSize: 34, fontWeight: '800', textAlign: 'center'},
  logoSmall: {color: colors.violet, fontSize: 23, fontWeight: '800'},
  hero: {color: colors.white, fontSize: 31, fontWeight: '800', textAlign: 'center', lineHeight: 43},
  title: {color: colors.white, fontSize: 23, fontWeight: '800', textAlign: 'center'},
  muted: {color: colors.muted, fontSize: 14, lineHeight: 24, textAlign: 'center'},
  panel: {padding: 22, backgroundColor: colors.panel, borderRadius: 20, borderWidth: 1, borderColor: colors.border, gap: 15},
  fieldLabel: {color: colors.white, fontSize: 16, textAlign: 'right', fontWeight: '700'},
  input: {color: colors.white, borderWidth: 1, borderColor: colors.border, borderRadius: 14, padding: 15, textAlign: 'left', backgroundColor: colors.bg, fontSize: 16},
  primary: {backgroundColor: colors.violet, paddingVertical: 16, borderRadius: 14, alignItems: 'center'},
  primaryText: {color: '#150e24', fontWeight: '800', fontSize: 15},
  link: {textAlign: 'center', color: '#c8b3ff', padding: 8},
  error: {textAlign: 'center', color: '#ff9baf', fontSize: 13, lineHeight: 22},
  header: {borderBottomWidth: 1, borderBottomColor: colors.border, padding: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between'},
  headerSubtitle: {color: colors.muted, fontSize: 9, marginTop: 3},
  signOut: {color: colors.muted, padding: 10},
  nav: {paddingHorizontal: 12, paddingVertical: 10, gap: 10, borderBottomWidth: 1, borderBottomColor: colors.border},
  newButton: {alignSelf: 'flex-end', backgroundColor: colors.panel2, borderWidth: 1, borderColor: colors.border, borderRadius: 12, padding: 9},
  newButtonText: {color: '#d0baff', fontWeight: '700'},
  navPill: {maxWidth: 160, backgroundColor: colors.panel, borderRadius: 20, paddingHorizontal: 13, paddingVertical: 8, borderWidth: 1, borderColor: colors.border},
  navPillActive: {borderColor: colors.violet},
  navPillText: {color: colors.white, fontSize: 12},
  empty: {flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40, gap: 17},
  sparkle: {fontSize: 65, color: colors.violet},
  messages: {padding: 14, gap: 12, paddingBottom: 24},
  bubble: {maxWidth: '92%', borderRadius: 17, padding: 14, gap: 8},
  userBubble: {backgroundColor: '#352255', alignSelf: 'flex-end'},
  aiBubble: {backgroundColor: colors.panel, alignSelf: 'flex-start', borderWidth: 1, borderColor: colors.border},
  bubbleTitle: {fontSize: 12, color: '#c7acff', fontWeight: '800'},
  bubbleText: {color: colors.white, fontSize: 15, lineHeight: 24, textAlign: 'auto'},
  chatError: {color: '#ff9baf', paddingHorizontal: 16, paddingVertical: 8, textAlign: 'center'},
  thinking: {color: colors.muted, paddingHorizontal: 18, paddingVertical: 7},
  composer: {paddingHorizontal: 12, paddingVertical: 12, borderTopWidth: 1, borderTopColor: colors.border, flexDirection: 'row', gap: 10, alignItems: 'flex-end'},
  composerInput: {flex: 1, color: colors.white, backgroundColor: colors.panel, borderRadius: 15, maxHeight: 120, minHeight: 48, padding: 12, textAlign: 'right', fontSize: 15},
  sendButton: {padding: 13, borderRadius: 13, backgroundColor: colors.violet, justifyContent: 'center', minHeight: 48},
});
